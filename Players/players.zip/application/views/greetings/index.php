<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Fun With Controllers</title>
  </head>
  <body>
    <a href="/greetings/show">Click Me</a>
  </body>
</html>