<div id="container">
          <h1>Date: <?php echo $michael['date']; ?></h1>
          <p>Message: <?php echo $michael['message']; ?></p>
</div>