<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>
		<form action="/home/login" method="post">
			<input type="text" name="email" placeholder="email" />
			<input type="password" name="password" placeholder="password" />
			<input type="submit" value="Login!" />
		</form>
	</body>
</html>
